This folder is to store videos inside your website. 

***Please note that in MOFH/Byet Free Hosting the max file size limit is 10mb so you may not be able to use this folder.***
We would suggest uploading your videos to an external platform like YouTube etc.

To embed embed videos into the script you must use an html code. 
This might help you: https://www.w3schools.com/html/html5_video.asp